import streamlit as st
from huggingface_hub import InferenceClient

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="QA Studio · HuggingFace",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@400;500&display=swap');

  /* ── Root tokens ── */
  :root {
    --bg:        #0d0f14;
    --surface:   #141720;
    --border:    #252a38;
    --accent:    #7c6af7;
    --accent2:   #3ecfcf;
    --text:      #e4e8f0;
    --muted:     #6b7385;
    --danger:    #f74b6a;
    --success:   #3ecfcf;
    --radius:    12px;
  }

  /* ── Global ── */
  html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
    background-color: var(--bg) !important;
    color: var(--text) !important;
  }

  /* ── Hide Streamlit chrome ── */
  #MainMenu, footer, header { visibility: hidden; }

  /* ── Sidebar ── */
  [data-testid="stSidebar"] {
    background: var(--surface) !important;
    border-right: 1px solid var(--border) !important;
  }
  [data-testid="stSidebar"] * { color: var(--text) !important; }

  /* ── Inputs & selects ── */
  .stTextInput > div > div > input,
  .stTextArea > div > div > textarea,
  .stSelectbox > div > div > div {
    background: var(--bg) !important;
    border: 1px solid var(--border) !important;
    border-radius: var(--radius) !important;
    color: var(--text) !important;
    font-family: 'DM Mono', monospace !important;
  }
  .stTextInput > div > div > input:focus,
  .stTextArea > div > div > textarea:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 3px rgba(124,106,247,.18) !important;
  }

  /* ── Sliders ── */
  .stSlider [data-baseweb="slider"] div[role="slider"] {
    background: var(--accent) !important;
  }
  .stSlider div[data-baseweb="slider"] > div:first-child {
    background: var(--border) !important;
  }

  /* ── Primary button ── */
  .stButton > button[kind="primary"],
  .stButton > button {
    background: linear-gradient(135deg, var(--accent), #9b59f5) !important;
    color: #fff !important;
    border: none !important;
    border-radius: var(--radius) !important;
    font-family: 'Syne', sans-serif !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    padding: .65rem 2.2rem !important;
    letter-spacing: .5px !important;
    transition: opacity .2s, transform .15s !important;
  }
  .stButton > button:hover { opacity: .88 !important; transform: translateY(-1px) !important; }

  /* ── Answer card ── */
  .answer-card {
    background: var(--surface);
    border: 1px solid var(--accent);
    border-radius: var(--radius);
    padding: 1.6rem 2rem;
    margin-top: 1.5rem;
    box-shadow: 0 0 28px rgba(124,106,247,.15);
  }
  .answer-card .label {
    font-size: .72rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--accent2);
    margin-bottom: .5rem;
  }
  .answer-card .answer-text {
    font-size: 1.55rem;
    font-weight: 700;
    line-height: 1.35;
  }
  .answer-card .score-row {
    margin-top: .8rem;
    font-family: 'DM Mono', monospace;
    font-size: .78rem;
    color: var(--muted);
  }

  /* ── Score bar ── */
  .score-bar-wrap { margin-top: .3rem; display: flex; align-items: center; gap: .7rem; }
  .score-bar-bg {
    flex: 1; height: 6px; background: var(--border); border-radius: 99px; overflow: hidden;
  }
  .score-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--accent2), var(--accent));
    border-radius: 99px;
    transition: width .6s ease;
  }

  /* ── Section divider ── */
  hr { border-color: var(--border) !important; }

  /* ── Instruction grid ── */
  .instr-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem; }
  .instr-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1rem 1.2rem;
  }
  .instr-card .ic-icon { font-size: 1.4rem; margin-bottom: .3rem; }
  .instr-card .ic-title { font-weight: 700; font-size: .85rem; margin-bottom: .25rem; }
  .instr-card .ic-body { font-size: .78rem; color: var(--muted); line-height: 1.5; }

  /* ── Pill badge ── */
  .pill {
    display: inline-block;
    background: rgba(124,106,247,.18);
    color: var(--accent);
    border-radius: 99px;
    padding: .15rem .7rem;
    font-size: .72rem;
    font-weight: 600;
    letter-spacing: .5px;
    margin-left: .4rem;
    vertical-align: middle;
  }

  /* ── Hero header ── */
  .hero { padding: 2rem 0 1rem; }
  .hero h1 {
    font-size: 2.8rem;
    font-weight: 800;
    line-height: 1.1;
    margin: 0;
    background: linear-gradient(135deg, #fff 30%, var(--accent));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  .hero p { color: var(--muted); font-size: .95rem; margin-top: .5rem; }
</style>
""", unsafe_allow_html=True)

# ── Model catalogue ────────────────────────────────────────────────────────────
MODELS = {
    "🔵 deepset / roberta-base-squad2":         "deepset/roberta-base-squad2",
    "🟣 deepset / deberta-v3-base-squad2":       "deepset/deberta-v3-base-squad2",
    "🟢 distilbert / distilbert-base-cased-distilled-squad": "distilbert/distilbert-base-cased-distilled-squad",
    "🟡 deepset / bert-base-cased-squad2":       "deepset/bert-base-cased-squad2",
    "🔴 timpal0l / mdeberta-v3-base-squad2":     "timpal0l/mdeberta-v3-base-squad2",
}

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuración")
    st.markdown("---")

    api_token = st.text_input(
        "🔑 HuggingFace API Token",
        type="password",
        placeholder="hf_xxxxxxxxxxxxxxxxxxxx",
        help="Obtén tu token en huggingface.co → Settings → Access Tokens",
    )

    st.markdown("#### 🤖 Modelo")
    model_label = st.selectbox("Selecciona un modelo", list(MODELS.keys()))
    model_id = MODELS[model_label]
    st.caption(f"`{model_id}`")

    st.markdown("#### 🎛️ Parámetros")
    max_answer_len = st.slider(
        "Longitud máxima de respuesta (tokens)",
        min_value=10, max_value=200, value=60, step=5,
    )
    top_k = st.slider(
        "Top-K respuestas candidatas",
        min_value=1, max_value=10, value=1, step=1,
        help="El modelo retorna las K respuestas más probables; se muestra la mejor.",
    )
    doc_stride = st.slider(
        "Document stride",
        min_value=32, max_value=256, value=128, step=32,
        help="Solapamiento de ventanas al procesar contextos largos.",
    )

    st.markdown("---")
    st.markdown(
        '<p style="font-size:.72rem;color:#6b7385;text-align:center;">'
        'QA Studio · Powered by 🤗 HuggingFace</p>',
        unsafe_allow_html=True,
    )

# ── Hero ───────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
  <h1>🧠 QA Studio</h1>
  <p>Extrae respuestas precisas de cualquier texto usando modelos de Question Answering de última generación.</p>
</div>
""", unsafe_allow_html=True)

# ── Main layout ────────────────────────────────────────────────────────────────
col_ctx, col_q = st.columns([3, 2], gap="large")

with col_ctx:
    st.markdown("### 📄 Contexto")
    context = st.text_area(
        label="contexto",
        label_visibility="collapsed",
        placeholder=(
            "Pega aquí el texto del que quieres extraer información.\n\n"
            "Puede ser un párrafo de Wikipedia, un contrato, un artículo, etc."
        ),
        height=320,
    )

with col_q:
    st.markdown("### ❓ Pregunta")
    question = st.text_input(
        label="pregunta",
        label_visibility="collapsed",
        placeholder="¿Cuál es la capital de Francia?",
    )

    st.markdown("<br>", unsafe_allow_html=True)

    run = st.button("⚡ Generar Respuesta", use_container_width=True)

    # ── Token status chip ──
    if api_token:
        st.markdown(
            '<p style="font-size:.75rem;color:#3ecfcf;margin-top:.4rem;">✅ Token detectado</p>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<p style="font-size:.75rem;color:#f74b6a;margin-top:.4rem;">'
            '⚠️ Ingresa tu token en la barra lateral</p>',
            unsafe_allow_html=True,
        )

# ── Inference ──────────────────────────────────────────────────────────────────
if run:
    # ── Validation ──
    if not api_token:
        st.error("🔐 **Token requerido** — ingresa tu HuggingFace API token en la barra lateral.")
        st.stop()
    if not context.strip():
        st.warning("📄 Por favor ingresa un **contexto** antes de continuar.")
        st.stop()
    if not question.strip():
        st.warning("❓ Por favor ingresa una **pregunta** antes de continuar.")
        st.stop()

    # ── Call API ──
    with st.spinner("🔍 Consultando el modelo…"):
        try:
            client = InferenceClient(
                model=model_id,
                token=api_token,
            )

            result = client.question_answering(
                question=question.strip(),
                context=context.strip(),
            )

            # Normalise response (SDK may return dict or object)
            if isinstance(result, dict):
                answer = result.get("answer", "Sin respuesta")
                score  = result.get("score", 0.0)
                start  = result.get("start", 0)
                end    = result.get("end", 0)
            else:
                answer = getattr(result, "answer", "Sin respuesta")
                score  = getattr(result, "score", 0.0)
                start  = getattr(result, "start", 0)
                end    = getattr(result, "end", 0)

            score_pct = round(float(score) * 100, 1)
            bar_width = min(int(score_pct), 100)

            st.markdown(f"""
            <div class="answer-card">
              <div class="label">Respuesta encontrada</div>
              <div class="answer-text">{answer}</div>
              <div class="score-row">
                Confianza: <strong>{score_pct}%</strong>
                &nbsp;·&nbsp; Posición en texto: [{start}:{end}]
                &nbsp;·&nbsp; Modelo: <code>{model_id}</code>
              </div>
              <div class="score-bar-wrap">
                <div class="score-bar-bg">
                  <div class="score-bar-fill" style="width:{bar_width}%"></div>
                </div>
                <span style="font-family:'DM Mono',monospace;font-size:.72rem;color:var(--muted);">
                  {bar_width}%
                </span>
              </div>
            </div>
            """, unsafe_allow_html=True)

            # Highlight answer in context
            with st.expander("🔎 Ver respuesta resaltada en el contexto"):
                highlighted = context.replace(
                    answer,
                    f"**:violet[{answer}]**",
                    1,
                )
                st.markdown(highlighted)

        except Exception as e:
            err = str(e)
            if "401" in err or "authorization" in err.lower() or "token" in err.lower():
                st.error(
                    "🔐 **Token inválido o sin permisos.** "
                    "Verifica que tu token tenga permisos de lectura en huggingface.co."
                )
            elif "503" in err or "loading" in err.lower():
                st.warning(
                    "⏳ **El modelo está cargando** (cold start). "
                    "Espera unos segundos y vuelve a intentarlo."
                )
            elif "connection" in err.lower() or "timeout" in err.lower():
                st.error(
                    "🌐 **Error de conexión.** "
                    "Revisa tu conexión a internet e intenta de nuevo."
                )
            else:
                st.error(f"❌ **Error inesperado:** {err}")

# ── Instructions ───────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📖 Cómo usar QA Studio")
st.markdown("""
<div class="instr-grid">
  <div class="instr-card">
    <div class="ic-icon">🔑</div>
    <div class="ic-title">1. Configura tu token</div>
    <div class="ic-body">
      Obtén un token gratuito en <strong>huggingface.co → Settings → Access Tokens</strong>
      e ingrésalo en la barra lateral. Se guarda sólo en esta sesión.
    </div>
  </div>
  <div class="instr-card">
    <div class="ic-icon">🤖</div>
    <div class="ic-title">2. Elige un modelo</div>
    <div class="ic-body">
      Cada modelo tiene fortalezas distintas. <em>RoBERTa</em> y <em>DeBERTa</em>
      son los más precisos; <em>DistilBERT</em> es el más rápido.
    </div>
  </div>
  <div class="instr-card">
    <div class="ic-icon">📄</div>
    <div class="ic-title">3. Ingresa el contexto</div>
    <div class="ic-body">
      Pega cualquier texto: artículos, documentos, descripciones.
      El modelo extrae la respuesta <em>directamente</em> del texto.
    </div>
  </div>
  <div class="instr-card">
    <div class="ic-icon">⚡</div>
    <div class="ic-title">4. Haz tu pregunta</div>
    <div class="ic-body">
      Formula preguntas concretas. El score de confianza indica
      qué tan seguro está el modelo de su respuesta.
    </div>
  </div>
</div>
""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)
st.caption("💡 **Tip:** Los modelos de QA extractivo sólo responden con fragmentos del contexto. Para respuestas generativas usa modelos de texto-a-texto.")
